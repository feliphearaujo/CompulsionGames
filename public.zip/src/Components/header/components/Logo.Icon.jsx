import logo from '../../../assets/img/compulsion-games-logo.svg'

export function Logo(){
    return(
        <>
            <img class='logoheader' src={logo} id="logo" style={{width:'200px'}}/>
        </>
    )
    
}